import React, { useState, useEffect, useCallback } from 'react';
import { HelpArticle } from '../types';
import { searchHelpArticles } from '../services/mockApi';

const ArticleCard: React.FC<{ article: HelpArticle, onClick: () => void }> = ({ article, onClick }) => (
  <div 
    onClick={onClick} 
    className="bg-white p-6 rounded-lg shadow-sm hover:shadow-lg transition-shadow duration-300 cursor-pointer"
  >
    <p className="text-sm text-emerald-600 font-medium mb-1">{article.category}</p>
    <h3 className="text-xl font-semibold text-gray-800 mb-2">{article.title}</h3>
    <p className="text-gray-600 line-clamp-2">{article.content}</p>
  </div>
);

const ArticleDetail: React.FC<{ article: HelpArticle, onBack: () => void }> = ({ article, onBack }) => (
  <div className="bg-white p-8 rounded-lg shadow-md">
    <button onClick={onBack} className="text-emerald-600 hover:text-emerald-800 mb-6">&larr; Back to articles</button>
    <p className="text-sm text-gray-500 mb-2">{article.category} &bull; Published on {article.createdAt.toLocaleDateString()}</p>
    <h1 className="text-3xl font-bold text-gray-900 mb-4">{article.title}</h1>
    <div className="prose max-w-none text-gray-700">
      <p>{article.content}</p>
    </div>
    <div className="mt-6">
        {article.tags.map(tag => (
            <span key={tag} className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#{tag}</span>
        ))}
    </div>
  </div>
);

const HelpCenterPage: React.FC = () => {
  const [articles, setArticles] = useState<HelpArticle[]>([]);
  const [filteredArticles, setFilteredArticles] = useState<HelpArticle[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<HelpArticle | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchArticles = async () => {
      setIsLoading(true);
      const allArticles = await searchHelpArticles('');
      setArticles(allArticles);
      setFilteredArticles(allArticles);
      setIsLoading(false);
    };
    fetchArticles();
  }, []);

  const handleSearch = useCallback(async (term: string) => {
    setSearchTerm(term);
    setIsLoading(true);
    const results = await searchHelpArticles(term);
    setFilteredArticles(results);
    setIsLoading(false);
  }, []);

  if (selectedArticle) {
    return <ArticleDetail article={selectedArticle} onBack={() => setSelectedArticle(null)} />;
  }
  
  return (
    <div>
      <h1 className="text-4xl font-bold text-center mb-4">Help Center</h1>
      <p className="text-lg text-gray-600 text-center mb-8">Find answers to your questions.</p>
      
      <div className="max-w-2xl mx-auto mb-10">
        <input
          type="search"
          value={searchTerm}
          onChange={(e) => handleSearch(e.target.value)}
          placeholder="Search for articles..."
          className="w-full px-5 py-3 text-base border border-gray-300 rounded-full focus:ring-2 focus:ring-emerald-400 focus:outline-none"
        />
      </div>

      {isLoading ? (
        <div className="text-center py-10">Loading articles...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.length > 0 ? (
            filteredArticles.map(article => (
              <ArticleCard key={article.id} article={article} onClick={() => setSelectedArticle(article)} />
            ))
          ) : (
            <p className="text-center col-span-full">No articles found for your search.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default HelpCenterPage;
