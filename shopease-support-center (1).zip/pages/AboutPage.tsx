import React from 'react';

const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md">
      <h1 className="text-4xl font-bold text-gray-800 mb-4">About ShopEase Support</h1>
      <div className="prose max-w-none text-gray-700">
        <p>
          Welcome to the ShopEase Support Center. Our mission is to provide you with quick, helpful, and clear solutions to any issues you might encounter while using our platform. We believe in empowering our customers with the knowledge and tools they need to succeed.
        </p>
        <h2 className="text-2xl font-semibold mt-6">Our Support Policy</h2>
        <p>
          We are committed to providing timely support for all our users. Our standard support hours are Monday to Friday, 9:00 AM to 5:00 PM (EST).
        </p>
        <ul>
          <li><strong>Response Time:</strong> We aim to respond to all new tickets within 24 business hours.</li>
          <li><strong>Resolution Time:</strong> While resolution times can vary depending on the complexity of the issue, we strive to resolve most problems within 3 business days.</li>
          <li><strong>Scope of Support:</strong> Our team can assist with technical issues, billing questions, and general guidance on using ShopEase features.</li>
        </ul>
        <h2 className="text-2xl font-semibold mt-6">How to Get Help</h2>
        <p>
          The best way to get help is by using our integrated chat support. You can start a new conversation or reopen an existing one using your Ticket ID. This ensures that our team has all the context of your previous interactions and can help you more efficiently. For general questions, feel free to browse our Help Center articles.
        </p>
      </div>
    </div>
  );
};

export default AboutPage;
