import React from 'react';
import { Page } from '../App';
import { HELP_CATEGORIES } from '../constants';

interface HomePageProps {
  navigate: (page: Page) => void;
}

const HomePage: React.FC<HomePageProps> = ({ navigate }) => {
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(Page.HelpCenter);
  };
  
  return (
    <div className="text-center">
      <section className="bg-white py-16 md:py-24 rounded-lg shadow-md">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            How can we help?
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            Find answers, articles, and resources to help you with ShopEase.
          </p>
          <form onSubmit={handleSearchSubmit} className="max-w-xl mx-auto relative">
            <input
              type="search"
              placeholder="Search help articles..."
              className="w-full px-5 py-4 text-lg border border-gray-300 rounded-full focus:ring-2 focus:ring-emerald-400 focus:outline-none"
            />
            <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-3 bg-emerald-500 text-white rounded-full hover:bg-emerald-600">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
          </form>
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-3xl font-bold text-gray-800 mb-8">
          Browse by Category
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {HELP_CATEGORIES.map((category) => (
            <button
              key={category.name}
              onClick={() => navigate(Page.HelpCenter)}
              className="bg-white p-6 rounded-lg shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 text-left"
            >
              <span className="text-3xl mr-4">{category.icon}</span>
              <span className="text-xl font-semibold text-gray-700">{category.name}</span>
            </button>
          ))}
        </div>
      </section>
      
      <section className="py-12">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Can't find what you're looking for?</h2>
        <p className="text-gray-600 mb-6">Our support team is here to help you.</p>
        <button 
          onClick={() => navigate(Page.Chat)}
          className="bg-emerald-500 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-emerald-600 transition-colors shadow-lg hover:shadow-xl"
        >
            Contact Support
        </button>
      </section>
    </div>
  );
};

export default HomePage;
