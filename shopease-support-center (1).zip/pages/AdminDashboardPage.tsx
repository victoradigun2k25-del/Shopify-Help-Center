import React, { useState, useEffect, useMemo } from 'react';
import { Ticket, TicketStatus } from '../types';
import { getAllTickets } from '../services/mockApi';

const statusColorMap: Record<TicketStatus, string> = {
  [TicketStatus.OPEN]: 'bg-red-100 text-red-800',
  [TicketStatus.IN_PROGRESS]: 'bg-blue-100 text-blue-800',
  [TicketStatus.CLOSED]: 'bg-gray-100 text-gray-800',
};

const TicketRow: React.FC<{ ticket: Ticket; onClick: () => void }> = ({ ticket, onClick }) => (
  <tr onClick={onClick} className="hover:bg-gray-50 cursor-pointer border-b">
    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{ticket.ticketId}</td>
    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{ticket.customerName}</td>
    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.customerEmail || 'N/A'}</td>
    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.lastMessageSnippet}</td>
    <td className="px-6 py-4 whitespace-nowrap">
      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColorMap[ticket.status]}`}>
        {ticket.status}
      </span>
    </td>
    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.lastMessageAt.toLocaleString()}</td>
  </tr>
);

const AdminDashboardPage: React.FC<{ onViewTicket: (ticketId: string) => void }> = ({ onViewTicket }) => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<TicketStatus | 'all'>('all');
  
  useEffect(() => {
    const fetchTickets = async () => {
      setIsLoading(true);
      const allTickets = await getAllTickets();
      setTickets(allTickets);
      setIsLoading(false);
    };
    fetchTickets();
  }, []);

  const filteredTickets = useMemo(() => {
    return tickets
      .filter(ticket => statusFilter === 'all' || ticket.status === statusFilter)
      .filter(ticket => 
        ticket.ticketId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ticket.customerName.toLowerCase().includes(searchTerm.toLowerCase())
      );
  }, [tickets, searchTerm, statusFilter]);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-3xl font-bold mb-6">Support Dashboard</h1>
      
      <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
        <input 
          type="text"
          placeholder="Search by Ticket ID or Name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-400"
        />
        <select 
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as TicketStatus | 'all')}
          className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-400 bg-white"
        >
          <option value="all">All Statuses</option>
          <option value={TicketStatus.OPEN}>Open</option>
          <option value={TicketStatus.IN_PROGRESS}>In Progress</option>
          <option value={TicketStatus.CLOSED}>Closed</option>
        </select>
      </div>

      {isLoading ? (
        <div className="text-center py-10">Loading tickets...</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ticket ID</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Message</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Update</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTickets.length > 0 ? (
                filteredTickets.map(ticket => (
                  <TicketRow key={ticket.id} ticket={ticket} onClick={() => onViewTicket(ticket.ticketId)} />
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-gray-500">No tickets found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminDashboardPage;