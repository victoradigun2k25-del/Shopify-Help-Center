import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Message, Ticket, SenderType } from '../types';
import { getTicketByTicketId, getMessagesForTicket, createTicket, addMessage } from '../services/mockApi';

const ChatBubble: React.FC<{ message: Message }> = ({ message }) => {
  const isUser = message.senderType === SenderType.USER;
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl ${isUser ? 'bg-emerald-500 text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'}`}>
        <p className="text-sm">{message.text}</p>
        <p className={`text-xs mt-1 ${isUser ? 'text-emerald-100' : 'text-gray-500'} text-right`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
};

const ChatPage: React.FC = () => {
    const [ticket, setTicket] = useState<Ticket | null>(null);
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [newMessage, setNewMessage] = useState('');

    // Form state
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [initialMessage, setInitialMessage] = useState('');
    const [ticketIdInput, setTicketIdInput] = useState('');

    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const storedTicketId = localStorage.getItem('shopease_ticket_id');
        if (storedTicketId) {
            setTicketIdInput(storedTicketId);
        }
    }, []);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const loadChat = useCallback(async (id: string) => {
        setIsLoading(true);
        setError(null);
        try {
            const foundTicket = await getTicketByTicketId(id);
            if (foundTicket) {
                const chatMessages = await getMessagesForTicket(id);
                setTicket(foundTicket);
                setMessages(chatMessages);
                localStorage.setItem('shopease_ticket_id', id);
            } else {
                setError('Ticket not found. Please check the ID or start a new conversation.');
                localStorage.removeItem('shopease_ticket_id');
            }
        } catch (e) {
            setError('An error occurred while loading your chat.');
        } finally {
            setIsLoading(false);
        }
    }, []);

    const handleFormSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (ticketIdInput.trim()) {
            await loadChat(ticketIdInput.trim());
        } else if (name.trim() && initialMessage.trim()) {
            setIsLoading(true);
            setError(null);
            try {
                const newTicket = await createTicket(name, initialMessage, email);
                setTicket(newTicket);
                const initialMessages = await getMessagesForTicket(newTicket.ticketId);
                setMessages(initialMessages);
                localStorage.setItem('shopease_ticket_id', newTicket.ticketId);
            } catch (e) {
                setError('Failed to start a new conversation. Please try again.');
            } finally {
                setIsLoading(false);
            }
        }
    };

    const handleSendMessage = async () => {
        if (!newMessage.trim() || !ticket) return;
        const tempMessage: Message = {
            id: 'temp',
            ticketId: ticket.ticketId,
            senderType: SenderType.USER,
            text: newMessage,
            timestamp: new Date()
        };
        setMessages(prev => [...prev, tempMessage]);
        setNewMessage('');
        
        await addMessage(ticket.ticketId, newMessage, SenderType.USER);
        const updatedMessages = await getMessagesForTicket(ticket.ticketId);
        setMessages(updatedMessages);
    };

    if (ticket) {
        return (
            <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-xl h-[70vh] flex flex-col">
                <div className="p-4 border-b flex justify-between items-center bg-gray-50 rounded-t-lg">
                    <div>
                        <h2 className="font-bold text-lg">Support Chat</h2>
                        <p className="text-sm text-gray-500">Ticket ID: <span className="font-mono">{ticket.ticketId}</span></p>
                    </div>
                     <button onClick={() => { setTicket(null); localStorage.removeItem('shopease_ticket_id'); }} className="text-sm text-gray-600 hover:text-red-500">End Chat</button>
                </div>
                <div className="flex-grow p-4 space-y-4 overflow-y-auto bg-gray-100">
                    {messages.map(msg => <ChatBubble key={msg.id} message={msg} />)}
                    <div ref={chatEndRef} />
                </div>
                <div className="p-4 border-t bg-white rounded-b-lg">
                    <div className="flex items-center space-x-2">
                        <input
                            type="text"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            placeholder="Type your message..."
                            className="flex-grow px-4 py-2 border rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-400"
                        />
                        <button onClick={handleSendMessage} className="bg-emerald-500 text-white rounded-full p-3 hover:bg-emerald-600 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-xl mx-auto">
            <div className="bg-white p-8 rounded-lg shadow-md">
                <h1 className="text-3xl font-bold text-center mb-6">Contact Support</h1>
                <form onSubmit={handleFormSubmit}>
                    <div className="mb-6 p-4 bg-emerald-50 border-l-4 border-emerald-400 rounded-r-lg">
                        <h3 className="font-semibold text-emerald-800">Have a Ticket ID?</h3>
                        <p className="text-sm text-emerald-700 mb-2">Enter your Ticket ID to continue a previous conversation.</p>
                        <input
                            type="text"
                            placeholder="e.g. SE-ABC123"
                            value={ticketIdInput}
                            onChange={(e) => setTicketIdInput(e.target.value)}
                            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-400"
                        />
                    </div>
                    
                    <div className="text-center my-4 text-gray-500 font-semibold">OR</div>

                    <h3 className="font-semibold text-lg mb-4 text-gray-800">Start a New Conversation</h3>
                    <div className="space-y-4">
                        <input type="text" placeholder="Your Name" value={name} onChange={e => setName(e.target.value)} className="w-full px-3 py-2 border rounded-md" required={!ticketIdInput} />
                        <input type="email" placeholder="Your Email (Optional)" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-3 py-2 border rounded-md" />
                        <textarea placeholder="How can we help?" value={initialMessage} onChange={e => setInitialMessage(e.target.value)} className="w-full px-3 py-2 border rounded-md h-28" required={!ticketIdInput}></textarea>
                    </div>

                    {error && <p className="text-red-500 text-sm mt-4">{error}</p>}

                    <button type="submit" disabled={isLoading} className="w-full mt-6 bg-emerald-500 text-white font-bold py-3 px-4 rounded-md hover:bg-emerald-600 transition-colors disabled:bg-emerald-300">
                        {isLoading ? 'Loading...' : (ticketIdInput ? 'Load Chat' : 'Start Chat')}
                    </button>
                </form>
            </div>
        </div>
    );
};

export default ChatPage;
