import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Message, Ticket, SenderType, TicketStatus } from '../types';
import { getTicketByTicketId, getMessagesForTicket, addMessage, updateTicketStatus } from '../services/mockApi';

const AdminChatBubble: React.FC<{ message: Message }> = ({ message }) => {
  const isAdmin = message.senderType === SenderType.ADMIN;
  return (
    <div className={`flex ${isAdmin ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl ${isAdmin ? 'bg-emerald-500 text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'}`}>
        <p className="font-bold text-sm mb-1">{isAdmin ? 'You' : 'Customer'}</p>
        <p className="text-sm">{message.text}</p>
        <p className={`text-xs mt-1 ${isAdmin ? 'text-emerald-100' : 'text-gray-500'} text-right`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
};

interface AdminChatViewPageProps {
  ticketId: string;
  onBack: () => void;
}

const AdminChatViewPage: React.FC<AdminChatViewPageProps> = ({ ticketId, onBack }) => {
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [newMessage, setNewMessage] = useState('');

  const chatEndRef = useRef<HTMLDivElement>(null);

  const fetchChatData = useCallback(async () => {
    const foundTicket = await getTicketByTicketId(ticketId);
    if (foundTicket) {
      const chatMessages = await getMessagesForTicket(ticketId);
      setTicket(foundTicket);
      setMessages(chatMessages);
    }
    setIsLoading(false);
  }, [ticketId]);

  useEffect(() => {
    setIsLoading(true);
    fetchChatData();
  }, [fetchChatData]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleSendMessage = async () => {
    if (!newMessage.trim() || !ticket) return;
    const tempMessage: Message = {
        id: 'temp-admin',
        ticketId: ticket.ticketId,
        senderType: SenderType.ADMIN,
        text: newMessage,
        timestamp: new Date()
    };
    setMessages(prev => [...prev, tempMessage]);
    setNewMessage('');
    
    await addMessage(ticket.ticketId, newMessage, SenderType.ADMIN);
    await fetchChatData(); // Re-fetch all data to get latest status and messages
  };

  const handleStatusChange = async (newStatus: TicketStatus) => {
    if (!ticket) return;
    const updatedTicket = await updateTicketStatus(ticket.ticketId, newStatus);
    setTicket(updatedTicket);
  };

  if (isLoading) {
    return <div className="text-center p-10">Loading conversation...</div>;
  }

  if (!ticket) {
    return <div className="text-center p-10 text-red-500">Could not load ticket data.</div>;
  }

  return (
    <div className="flex gap-8">
        <div className="w-2/3">
            <div className="bg-white rounded-lg shadow-xl h-[70vh] flex flex-col">
                <div className="p-4 border-b flex justify-between items-center bg-gray-50 rounded-t-lg">
                    <div>
                        <button onClick={onBack} className="text-sm text-emerald-600 hover:text-emerald-800 mb-1">&larr; Back to Dashboard</button>
                        <h2 className="font-bold text-lg">Conversation with {ticket.customerName}</h2>
                        <p className="text-sm text-gray-500">Ticket ID: <span className="font-mono">{ticket.ticketId}</span></p>
                    </div>
                </div>
                <div className="flex-grow p-4 space-y-4 overflow-y-auto bg-gray-100">
                    {messages.map(msg => <AdminChatBubble key={msg.id} message={msg} />)}
                    <div ref={chatEndRef} />
                </div>
                <div className="p-4 border-t bg-white rounded-b-lg">
                    <div className="flex items-center space-x-2">
                        <input
                            type="text"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            placeholder="Type your reply..."
                            className="flex-grow px-4 py-2 border rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-400"
                        />
                        <button onClick={handleSendMessage} className="bg-emerald-500 text-white rounded-full p-3 hover:bg-emerald-600 transition-colors">
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div className="w-1/3 bg-white p-6 rounded-lg shadow-xl self-start">
            <h3 className="font-bold text-xl mb-4 border-b pb-2">Ticket Details</h3>
            <div className="space-y-3 text-sm">
                <p><strong>Customer:</strong> {ticket.customerName}</p>
                <p><strong>Email:</strong> {ticket.customerEmail || 'Not provided'}</p>
                <p><strong>Created:</strong> {ticket.createdAt.toLocaleString()}</p>
                <div className="pt-2">
                    <label className="font-bold block mb-1">Status</label>
                    <select
                        value={ticket.status}
                        onChange={(e) => handleStatusChange(e.target.value as TicketStatus)}
                        className="w-full p-2 border rounded-md bg-white"
                    >
                        <option value={TicketStatus.OPEN}>Open</option>
                        <option value={TicketStatus.IN_PROGRESS}>In Progress</option>
                        <option value={TicketStatus.CLOSED}>Closed</option>
                    </select>
                </div>
                 <button
                  onClick={() => handleStatusChange(TicketStatus.CLOSED)}
                  disabled={ticket.status === TicketStatus.CLOSED}
                  className="w-full mt-4 bg-emerald-500 text-white font-bold py-2 px-4 rounded-md hover:bg-emerald-600 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  Mark as Resolved
                </button>
            </div>
        </div>
    </div>
  );
};

export default AdminChatViewPage;