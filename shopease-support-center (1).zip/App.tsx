import React, { useState, useCallback, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import HelpCenterPage from './pages/HelpCenterPage';
import ChatPage from './pages/ChatPage';
import AdminLoginPage from './pages/AdminLoginPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import AdminChatViewPage from './pages/AdminChatViewPage';
import AboutPage from './pages/AboutPage';

export enum Page {
  Home,
  HelpCenter,
  Chat,
  AdminLogin,
  AdminDashboard,
  AdminChat,
  About,
}

const App: React.FC = () => {
  const [page, setPage] = useState<Page>(Page.Home);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);

  const navigate = useCallback((targetPage: Page) => {
    setPage(targetPage);
  }, []);

  useEffect(() => {
    if (window.location.pathname === '/admin') {
      navigate(Page.AdminLogin);
    }
  }, [navigate]);

  const handleAdminLogin = useCallback(() => {
    setIsAdmin(true);
    setPage(Page.AdminDashboard);
  }, []);

  const handleAdminLogout = useCallback(() => {
    setIsAdmin(false);
    setPage(Page.Home);
  }, []);

  const handleViewTicket = useCallback((ticketId: string) => {
    setSelectedTicketId(ticketId);
    setPage(Page.AdminChat);
  }, []);
  
  const handleBackToDashboard = useCallback(() => {
    setSelectedTicketId(null);
    setPage(Page.AdminDashboard);
  }, []);

  const renderPage = () => {
    switch (page) {
      case Page.Home:
        return <HomePage navigate={navigate} />;
      case Page.HelpCenter:
        return <HelpCenterPage />;
      case Page.Chat:
        return <ChatPage />;
      case Page.About:
        return <AboutPage />;
      case Page.AdminLogin:
        return <AdminLoginPage onLoginSuccess={handleAdminLogin} />;
      case Page.AdminDashboard:
        if (!isAdmin) {
          return <AdminLoginPage onLoginSuccess={handleAdminLogin} />;
        }
        return <AdminDashboardPage onViewTicket={handleViewTicket} />;
      case Page.AdminChat:
        if (!isAdmin || !selectedTicketId) {
          return <AdminLoginPage onLoginSuccess={handleAdminLogin} />;
        }
        return <AdminChatViewPage ticketId={selectedTicketId} onBack={handleBackToDashboard} />;
      default:
        return <HomePage navigate={navigate} />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen font-sans text-gray-800">
      <Header navigate={navigate} isAdmin={isAdmin} onLogout={handleAdminLogout} />
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        {renderPage()}
      </main>
      <Footer navigate={navigate} />
    </div>
  );
};

export default App;