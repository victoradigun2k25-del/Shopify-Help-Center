import { HelpArticle, Ticket, Message, TicketStatus, SenderType } from '../types';

// --- MOCK DATABASE ---

let helpArticles: HelpArticle[] = [
  { id: '1', title: 'How to process a refund?', category: 'Payments', content: 'To process a refund, go to the order details page and click the "Refund" button. You can choose to refund the full amount or a partial amount.', tags: ['refund', 'payment', 'order'], createdAt: new Date('2023-10-26') },
  { id: '2', title: 'What are the shipping options?', category: 'Shipping', content: 'We offer Standard, Express, and Next-Day shipping. Costs and delivery times vary by location. You can see the available options at checkout.', tags: ['shipping', 'delivery', 'options'], createdAt: new Date('2023-10-25') },
  { id: '3', title: 'How do I reset my password?', category: 'Account Setup', content: 'Click on "Forgot Password" on the login page. An email will be sent to you with a link to reset your password.', tags: ['password', 'account', 'login'], createdAt: new Date('2023-10-24') },
  { id: '4', title: 'Return Policy', category: 'Returns & Refunds', content: 'You can return any item within 30 days of purchase for a full refund, provided it is in its original condition.', tags: ['return', 'policy', 'refund'], createdAt: new Date('2023-10-23') },
];

let tickets: Ticket[] = [];
let messages: Message[] = [];
let idCounter = { article: 5, ticket: 1, message: 1 };

// --- UTILITY FUNCTIONS ---

const generateTicketId = () => `SE-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));


// --- API FUNCTIONS ---

export const searchHelpArticles = async (query: string): Promise<HelpArticle[]> => {
  await delay(300);
  if (!query) return helpArticles;
  const lowerCaseQuery = query.toLowerCase();
  return helpArticles.filter(article => 
    article.title.toLowerCase().includes(lowerCaseQuery) ||
    article.content.toLowerCase().includes(lowerCaseQuery) ||
    article.tags.some(tag => tag.toLowerCase().includes(lowerCaseQuery))
  );
};

export const getTicketByTicketId = async (ticketId: string): Promise<Ticket | null> => {
    await delay(300);
    const ticket = tickets.find(t => t.ticketId === ticketId);
    return ticket || null;
}

export const getMessagesForTicket = async (ticketId: string): Promise<Message[]> => {
    await delay(300);
    return messages.filter(m => m.ticketId === ticketId).sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
}

export const createTicket = async (customerName: string, firstMessage: string, customerEmail?: string): Promise<Ticket> => {
    await delay(500);
    const now = new Date();
    const newTicket: Ticket = {
        id: (idCounter.ticket++).toString(),
        ticketId: generateTicketId(),
        customerName,
        customerEmail,
        status: TicketStatus.OPEN,
        createdAt: now,
        lastMessageAt: now,
        lastMessageSnippet: firstMessage.substring(0, 40) + (firstMessage.length > 40 ? '...' : '')
    };
    tickets.push(newTicket);

    const newMessage: Message = {
        id: (idCounter.message++).toString(),
        ticketId: newTicket.ticketId,
        senderType: SenderType.USER,
        text: firstMessage,
        timestamp: now,
    };
    messages.push(newMessage);
    
    // Simulate admin email notification
    console.log(`--- ADMIN NOTIFICATION ---`);
    console.log(`New ticket ${newTicket.ticketId} from ${customerName}`);
    console.log(`Message: ${firstMessage}`);
    console.log(`------------------------`);

    return newTicket;
};

export const addMessage = async (ticketId: string, text: string, senderType: SenderType): Promise<Message> => {
    await delay(400);
    const now = new Date();
    const ticket = tickets.find(t => t.ticketId === ticketId);

    if (!ticket) {
        throw new Error('Ticket not found');
    }

    const newMessage: Message = {
        id: (idCounter.message++).toString(),
        ticketId,
        senderType,
        text,
        timestamp: now
    };
    messages.push(newMessage);

    ticket.lastMessageAt = now;
    ticket.lastMessageSnippet = text.substring(0, 40) + (text.length > 40 ? '...' : '');
    if (senderType === SenderType.ADMIN) {
        ticket.status = TicketStatus.IN_PROGRESS;
    }

    if (senderType === SenderType.USER) {
        console.log(`--- ADMIN NOTIFICATION ---`);
        console.log(`New message in ticket ${ticketId}`);
        console.log(`From: ${ticket.customerName}`);
        console.log(`Message: ${text}`);
        console.log(`------------------------`);
    }

    return newMessage;
}

export const getAllTickets = async (): Promise<Ticket[]> => {
    await delay(500);
    return [...tickets].sort((a, b) => b.lastMessageAt.getTime() - a.lastMessageAt.getTime());
}

export const updateTicketStatus = async (ticketId: string, status: TicketStatus): Promise<Ticket> => {
    await delay(200);
    const ticket = tickets.find(t => t.ticketId === ticketId);
    if (!ticket) {
        throw new Error('Ticket not found');
    }
    ticket.status = status;
    return ticket;
}
