import React from 'react';

export const HELP_CATEGORIES = [
  { name: 'Payments', icon: '💳' },
  { name: 'Shipping', icon: '🚚' },
  { name: 'Account Setup', icon: '👤' },
  { name: 'Returns & Refunds', icon: '🔄' },
  { name: 'Product Issues', icon: '📦' },
  { name: 'Technical Support', icon: '⚙️' },
];

export const Logo: React.FC = () => (
  <div className="flex items-center space-x-2">
    <svg 
      className="w-8 h-8 text-emerald-500"
      viewBox="0 0 24 24" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
    <span className="font-bold text-xl text-gray-800">ShopEase</span>
  </div>
);
