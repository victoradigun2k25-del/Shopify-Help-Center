export enum TicketStatus {
  OPEN = 'Open',
  IN_PROGRESS = 'In Progress',
  CLOSED = 'Closed',
}

export enum SenderType {
  USER = 'user',
  ADMIN = 'admin',
}

export interface HelpArticle {
  id: string;
  title: string;
  category: string;
  content: string;
  tags: string[];
  createdAt: Date;
}

export interface Ticket {
  id: string; // internal id
  ticketId: string; // public id
  customerName: string;
  customerEmail?: string;
  status: TicketStatus;
  createdAt: Date;
  lastMessageAt: Date;
  lastMessageSnippet: string;
}

export interface Message {
  id: string;
  ticketId: string; // public id
  senderType: SenderType;
  text: string;
  timestamp: Date;
}
