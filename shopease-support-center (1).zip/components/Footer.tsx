import React from 'react';
import { Page } from '../App';

interface FooterProps {
  navigate: (page: Page) => void;
}


const Footer: React.FC<FooterProps> = ({ navigate }) => {
  return (
    <footer className="bg-gray-100 border-t border-gray-200">
      <div className="container mx-auto px-4 py-6 text-center text-gray-500">
        <p>&copy; {new Date().getFullYear()} ShopEase Support Center. All rights reserved.</p>
        <div className="mt-2">
            <button onClick={() => navigate(Page.About)} className="hover:text-emerald-500 mx-2">About Us</button>
            <a href="#" className="hover:text-emerald-500 mx-2">Privacy Policy</a>
            <a href="#" className="hover:text-emerald-500 mx-2">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;