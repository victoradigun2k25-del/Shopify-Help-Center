import React from 'react';
import { Page } from '../App';
import { Logo } from '../constants';

interface HeaderProps {
  navigate: (page: Page) => void;
  isAdmin: boolean;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ navigate, isAdmin, onLogout }) => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <button onClick={() => navigate(Page.Home)} className="cursor-pointer">
          <Logo />
        </button>
        <nav className="flex items-center space-x-4 md:space-x-6">
          <button
            onClick={() => navigate(Page.Home)}
            className="text-gray-600 hover:text-emerald-500 transition-colors duration-200"
          >
            Home
          </button>
          <button
            onClick={() => navigate(Page.HelpCenter)}
            className="text-gray-600 hover:text-emerald-500 transition-colors duration-200"
          >
            Help Center
          </button>
          {isAdmin ? (
            <>
              <button
                onClick={() => navigate(Page.AdminDashboard)}
                className="text-gray-600 hover:text-emerald-500 transition-colors duration-200"
              >
                Dashboard
              </button>
              <button
                onClick={onLogout}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md text-sm font-medium hover:bg-gray-300 transition-colors"
              >
                Logout
              </button>
            </>
          ) : (
            <button
              onClick={() => navigate(Page.Chat)}
              className="bg-emerald-500 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-emerald-600 transition-colors"
            >
              Contact Support
            </button>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;
